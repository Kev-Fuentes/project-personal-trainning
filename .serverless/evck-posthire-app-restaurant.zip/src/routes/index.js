const foodsRouter = require('./foods');

module.exports = {
  foodsRouter,
};
