const foodsSchema = require('./foods');

module.exports = {
  foodsSchema,
};
