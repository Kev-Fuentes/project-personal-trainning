const Food = require('./foods');

module.exports = {
  Food,
};
