const status = require('./statusHttp');

module.exports = {
  status,
};
