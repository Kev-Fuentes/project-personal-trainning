const foodsController = require('./foodsController');

module.exports = {
  foodsController,
};
