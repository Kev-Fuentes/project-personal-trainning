const { schemaPostFood, schemaPatchFood } = require('./food');

module.exports = {
  schemaPostFood,
  schemaPatchFood,
};
